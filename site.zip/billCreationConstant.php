<?php
define("MAX_BILLS", 3);
?>
